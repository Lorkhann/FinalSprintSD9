// QAP 5 written By Liam Philpott
fetch('Family.json')
     .then(results => results.json())
     .then(family =>{
          console.log("JSON DATA:", family)
          family.forEach(member => {
                // Check Arrays through changes and ensure Info is correctly inpiutted //
                member.Birthday = new Date(member.Birthday);
                const memberContainer = document.getElementById("member-container"); 
                const FamilyInfo = displayFamilyInfo(member);
                const showInfo = showFamilyInfo(member);
                console.log(showInfo);
          });
     })

     .catch(error => {
          console.error(error);
     })

     function getFullName(member) {
          return `${member.fname} ${member.lname}`;
     }

     function getBirthday(member) {
          return `${member.fname} was born in ${member.Birthday} meaning he is ${new Date().getFullYear() -
               new Date(member.Birthday).getFullYear()} years old!`
     }


     function getFavouriteSport(member){
          return `${member.fname}'s favourite sport is ${member.FavouriteSport}`
     }

     function getFavouriteNumber(member){
          return `${member.FavouriteNumber}`
     }

     function getIsProgrammer(member){
          switch(member.IsProgrammer){
               case(member.IsProgrammer = true):
                    return `${member.fname} is either a programmer or learning to be one.. Nice!`

               case (member.IsProgrammer = false):
                    return `${member.fname} Is not a programmer... Sad!`

          }
     }

     function getHobbies(member){
          return `${member.fname} favourite hobbies are ${member.Hobbies}`
     }

     function Hobbies(member) {
          switch(member.Hobbies){
               case "Procastinating":
                    console.log(`${member.Name} You should really stop delaying things till the last minute!`);
                    break;
               case "Reading":
                    console.log(`${member.Name} Loves to read Fantasy books, specifically Tolkein!`);
               break;
               case "Annoying Brothers":
                    console.log (`${member.Name} Should really stop annoying his brothers...`);
          }
       }

     function VerifyAge(member) {
          const currentYear = new Date().getFullYear();
          const currentMonth = new Date().getMonth();
          const currentDate = new Date().getDate();
              
          const dobYear = member.Birthday.getFullYear();
          const dobMonth =  member.Birthday.getMonth();
          const dobDate = member.Birthday.getDate();
          
          let yearAge = currentYear - dobYear;
          let monthAge = currentMonth - dobMonth;
          let dateAge = currentDate - dobDate;
      
          if (currentMonth < dobMonth || (currentMonth === dobMonth && currentDate < dobDate)) {
            yearAge--;
            monthAge += 12;}
          
          if (currentDate < dobDate) {
            monthAge--;
            dateAge += 31;}
      
          const Tage = {
            years: yearAge,
            months: monthAge,
            days: dateAge 
          }
      
          const ageString = Tage.years + " years, " + Tage.months + " months, and " + Tage.days + " days old"
      
          return ageString;
        };
      
        function displayFamilyInfo(member){
          const age = VerifyAge(member);
          const FullName =getFullName(member);

          return`
          <div class ="FamilyInfo">
          <h1> ${FullName}</h1>
          <hr>
          <br>
          <br>
          <p>Birthday: ${member.Birthday.toLocaleDateString()}</p><br>
          <p>Age: ${age}</p><br>
          <p>Favourite Sport: ${member.FavouriteSport}</p><br>
          <p>Favourite Number: ${member.FavouriteNumber}</p><br>
          <p>Is Programmer?: ${member.IsProgrammer}</p><br>
          <p>Hobbies: ${member.Hobbies}</p><br>
          

          <br clear = "all">
          </div>
          `
     }
     function showFamilyInfo(member) {
          return `
      
          Name: ${getFullName(member)}
          Birthday: ${member.Birthday.toLocaleDateString()}
          Age: ${VerifyAge(member)}
          Favourite Sport: ${member.FavouriteSport}
          Favourite Number: ${member.FavouriteNumber}
          Hobbies: ${member.Hobbies}
          Is Programmer: ${member.IsProgrammer}
      
          `;
        };

fetch(`HeroesRES.json`)
     .then(res => res.json())
     .then(data =>{
          console.log("JSON Data:", data);
          data.forEach(Super => {
               console.log(getRealName(Super));
               console.log(getHeroName(Super));
               console.log(getGender(Super));
               console.log(getFact(Super));

          });
          Status.forEach(Status => {
               console.log(Status);
          });
     })

     .catch(error => {
          console.error(error);
     })



     function getHeroName(Super) {
          return `${Super.HeroName} is their fake identity`;
     }


     function getRealName(Super) {
          return `${Super.HeroName} is actually ${Super.RealName}!!!`;
     }

     function getGender(Super) {
          return `${Super.HeroName} is a ${Super.Gender}`;
     }


     function Status(Super) {
          switch(Super.Status) {
               case "Alive":
                    console.log(`${Super.HeroName} is Active, and on the job!`);
                    break;
               case "Dead":
                    console.log (`${Super.HeroName} will likely be back next Issue...`);
                    break;
               case "On Vacation":
                    console.log(`${Super.HeroName} job is never done! Back to work!`);
                    break;
               default:
                    console.log(`${Super.HeroName} lets be honest here... Theres no rest for a DC Hero...`);
          }
     };

     function getFact(Super) {
          return `Fact: ${Super.InterestingFact}!!!`;
     }